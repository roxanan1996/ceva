#include <iostream>
using namespace std;

int main() {
	delete NULL;
	cout<<5<<"\n";
	return 0;
}